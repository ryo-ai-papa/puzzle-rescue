import { describe, it, expect } from "vitest";
import { makePuzzle, reverse, isTarget, type Cubic } from "./puzzle";
const rng = (seed: number) => () => {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return seed / 4294967296;
};
const at = (c: Cubic, t: number) => {
  const u = 1 - t;
  return {
    x:
      u ** 3 * c.from.x +
      3 * u * u * t * c.a.x +
      3 * u * t * t * c.b.x +
      t ** 3 * c.to.x,
    y:
      u ** 3 * c.from.y +
      3 * u * u * t * c.a.y +
      3 * u * t * t * c.b.y +
      t ** 3 * c.to.y,
  };
};
describe("random shared-edge jigsaw", () => {
  it.each([
    [1000, 600],
    [600, 1000],
    [1000, 700],
    [600, 1100],
  ])("16 pieces, matching shared curves, safe bounds at %i x %i", (w, h) => {
    for (let seed = 1; seed <= 40; seed++) {
      const p = makePuzzle(w, h, rng(seed));
      expect(p.pieces).toHaveLength(16);
      expect(new Set(p.order).size).toBe(16);
      for (const piece of p.pieces) {
        expect(piece.path).toContain("C");
        expect(piece.edges.some((e) => e.length === 5)).toBe(true);
        if (piece.col < 3)
          expect(piece.edges[1]).toEqual(
            reverse(p.pieces[piece.id + 1].edges[3]),
          );
        if (piece.row < 3)
          expect(piece.edges[2]).toEqual(
            reverse(p.pieces[piece.id + 4].edges[0]),
          );
        piece.edges.forEach((edge, i) => {
          const next = piece.edges[(i + 1) % 4];
          expect(edge.at(-1)!.to).toEqual(next[0].from);
          for (const c of edge)
            for (let t = 0; t <= 1; t += 0.05) {
              const q = at(c, t);
              if (
                q.x < p.frame -0.00001 ||
                q.y < p.frame -0.00001 ||
                q.x > w - p.frame + 0.00001 ||
                q.y > h - p.frame + 0.00001 ||
                q.x < p.frame + piece.col*p.cellW-p.pad ||
                q.x > p.frame + (piece.col+1)*p.cellW+p.pad ||
                q.y < p.frame + piece.row*p.cellH-p.pad ||
                q.y > p.frame + (piece.row+1)*p.cellH+p.pad
              )
                throw new Error(
                  `Out of bounds: seed ${seed}, piece ${piece.id}`,
                );
            }
        });
      }
    }
  });
  it("new seeds produce new curves and shuffles", () => {
    const a = makePuzzle(1000, 700, rng(1)),
      b = makePuzzle(1000, 700, rng(2));
    expect(a.pieces.map((p) => p.path)).not.toEqual(
      b.pieces.map((p) => p.path),
    );
    expect(a.order).not.toEqual(b.order);
  });
  it.each([[1280,720],[720,1280],[1280,960],[590,949]])('covers the inset exactly once at sampled points: %i × %i',(w,h)=>{
    const inside=(points:{x:number,y:number}[],x:number,y:number)=>{
      let result=false;
      for(let i=0,j=points.length-1;i<points.length;j=i++){
        const a=points[i],b=points[j];
        if((a.y>y)!==(b.y>y)&&x<(b.x-a.x)*(y-a.y)/(b.y-a.y)+a.x)result=!result;
      }
      return result;
    };
    for(let seed=1;seed<=12;seed++){
      const p=makePuzzle(w,h,rng(seed));
      const polygons=p.pieces.map(piece=>piece.edges.flatMap(edge=>edge.flatMap(c=>Array.from({length:24},(_,i)=>at(c,i/24)))));
      for(let row=0;row<30;row++)for(let col=0;col<30;col++){
        const x=p.frame+(w-2*p.frame)*(col+.37)/30,y=p.frame+(h-2*p.frame)*(row+.43)/30;
        const count=polygons.filter(poly=>inside(poly,x,y)).length;
        if(count!==1)throw new Error(`Gap/overlap: seed ${seed}, ${x}, ${y}, count ${count}`);
      }
    }
  });
  it("accepts only the correct target, even with help", () => {
    const p = makePuzzle(1000, 700);
    for (const piece of p.pieces)
      for (const other of p.pieces) {
        expect(
          isTarget(
            p,
            piece.id,
            p.frame + (other.col + 0.5) * p.cellW,
            p.frame + (other.row + 0.5) * p.cellH,
            true,
          ),
        ).toBe(piece.id === other.id);
      }
    expect(isTarget(p, 0, -100, -100, true)).toBe(false);
  });
});

