// @vitest-environment jsdom
import React from "react";
import { afterEach, beforeEach, describe, it, expect, vi } from "vitest";
import {
  render,
  screen,
  fireEvent,
  cleanup,
  waitFor,
  act,
} from "@testing-library/react";
import { App, stages } from "./App";
vi.mock("./audio", () => ({ sound: vi.fn(), unlockAudio: vi.fn() }));
let portrait = false,
  missing = false;
const dimensions = [[1280,720],[1280,720],[1280,960],[1280,720]];
beforeEach(() => {
  localStorage.clear();
  portrait = false;
  missing = false;
  vi.stubGlobal(
    "Image",
    class {
      onload: () => void = () => {};
      onerror: () => void = () => {};
      naturalWidth = 1000;
      naturalHeight = 800;
      set src(src: string) {
        const index = stages.findIndex(stage => src.endsWith(stage.file));
        [this.naturalWidth, this.naturalHeight] = dimensions[index];
        queueMicrotask(() => (missing ? this.onerror() : this.onload()));
      }
    },
  );
  vi.stubGlobal("PointerEvent", MouseEvent);
  window.matchMedia = vi.fn().mockImplementation(() => ({ matches: portrait }));
  HTMLElement.prototype.setPointerCapture = vi.fn();
  vi.spyOn(SVGElement.prototype, "getBoundingClientRect").mockReturnValue({
    left: 0,
    top: 0,
    width: 400,
    height: 320,
    right: 400,
    bottom: 320,
    x: 0,
    y: 0,
    toJSON: () => {},
  });
});
afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  vi.useRealTimers();
});
async function start(i = 0) {
  render(<App />);
  await waitFor(() =>
    expect(
      (
        screen.getByRole("button", {
          name: new RegExp(stages[i].name),
        }) as HTMLButtonElement
      ).disabled,
    ).toBe(false),
  );
  fireEvent.click(
    screen.getByRole("button", { name: new RegExp(stages[i].name) }),
  );
}
function choose(id: number) {
  fireEvent.click(screen.getByRole("button", { name: `ピース ${id + 1}` }));
}
function place(id: number) {
  choose(id);
  fireEvent.click(screen.getByTestId("board"), {
    clientX: ((id % 4) + 0.5) * 100,
    clientY: (Math.floor(id / 4) + 0.5) * 80,
  });
}
describe("game interaction", () => {
  it('starts with empty sockets, a printed frame and both assists OFF', async()=>{
    await start();
    expect(screen.getByRole('button',{name:/みほん/}).getAttribute('aria-pressed')).toBe('false');
    expect(screen.getByRole('button',{name:/おたすけ/}).getAttribute('aria-pressed')).toBe('false');
    expect(screen.getByRole('button',{name:'サウンド'}).getAttribute('aria-pressed')).toBe('true');
    expect(screen.getByTestId('frame-image').getAttribute('mask')).toBe('url(#picture-frame)');
    expect(document.querySelectorAll('.socket')).toHaveLength(16);
    expect(screen.queryAllByTestId('ghost-image')).toHaveLength(0);
    choose(0);
    expect(document.querySelector('.board .lit')).toBeNull();
    vi.useFakeTimers();
    fireEvent.click(screen.getByRole('button',{name:/おたすけ/}));
    fireEvent.click(screen.getByRole('button',{name:/おたすけ/}));
    act(()=>vi.advanceTimersByTime(13000));
    expect(document.querySelector('.board .lit')).toBeNull();
    fireEvent.click(screen.getByRole('button',{name:/ヒント/}));
    expect(document.querySelector('.board .lit')).toBeTruthy();
    fireEvent.click(screen.getByRole('button',{name:/みほん/}));
    expect(screen.getAllByTestId('ghost-image')).toHaveLength(16);
    fireEvent.click(screen.getByRole('button',{name:/みほん/}));
    expect(screen.queryAllByTestId('ghost-image')).toHaveLength(0);
  });
  it('migrates old clear records but turns old assists off once',async()=>{
    localStorage.setItem('puzzle-rescue-v1',JSON.stringify({sound:false,help:true,ghost:true,cleared:[2]}));
    await start();
    const saved=JSON.parse(localStorage.getItem('puzzle-rescue-v2')!);
    expect(saved).toEqual({sound:false,help:false,ghost:false,cleared:[2]});
  });
  it('automatic hint is enabled only when help is on',async()=>{
    await start();
    vi.useFakeTimers();
    fireEvent.click(screen.getByRole('button',{name:/おたすけ/}));
    act(()=>vi.advanceTimersByTime(13000));
    expect(document.querySelector('.tile.selected')).toBeTruthy();
    expect(document.querySelector('.board .lit')).toBeTruthy();
    fireEvent.click(screen.getByRole('button',{name:/おたすけ/}));
    expect(document.querySelector('.board .lit')).toBeNull();
  });
  it.each([0, 1, 2, 3])(
    "stage %i completes exactly 16 pieces and has its own celebration",
    async (i) => {
      await start(i);
      expect(screen.getByTestId('board').getAttribute('viewBox')).toBe('0 0 1000 562.5');
      for(const image of document.querySelectorAll('.board image, .tray image')) {
        expect(image.getAttribute('width')).toBe('1000');
        expect(image.getAttribute('height')).toBe('562.5');
        expect(image.getAttribute('preserveAspectRatio')).toBe('xMidYMid meet');
      }
      for(const image of document.querySelectorAll('.tray image')) {
        expect(image.getAttribute('href')).toContain(stages[i].file);
        expect(image.getAttribute('width')).toBe('1000');
        expect(image.getAttribute('clip-path')).toMatch(/^url\(#clip-tray-/);
      }
      expect(
        screen.getAllByRole("button", { name: /^ピース \d/ }),
      ).toHaveLength(16);
      for (let id = 0; id < 15; id++) place(id);
      expect(screen.queryByRole("dialog")).toBeNull();
      place(15);
      expect(screen.getByRole("dialog").className).toContain(`theme-${i}`);
      expect(screen.getByText(stages[i].win)).toBeTruthy();
      expect(
        JSON.parse(localStorage.getItem("puzzle-rescue-v2")!).cleared,
      ).toContain(i);
    },
  );
  it("wrong tap keeps selection; right tap fixes piece and rotation retains it", async () => {
    await start();
    choose(0);
    fireEvent.click(screen.getByTestId("board"), {
      clientX: 350,
      clientY: 280,
    });
    expect(
      screen
        .getByRole("button", { name: "ピース 1" })
        .getAttribute("aria-pressed"),
    ).toBe("true");
    place(0);
    fireEvent(window, new Event("orientationchange"));
    expect(screen.queryByRole("button", { name: "ピース 1" })).toBeNull();
    expect(screen.getAllByRole("button", { name: /^ピース \d/ })).toHaveLength(
      15,
    );
  });
  it("pointer drag places correctly; incorrect drop returns; cancel keeps pieces", async () => {
    await start();
    let b = screen.getByRole("button", { name: "ピース 1" });
    fireEvent.pointerDown(b, { button: 0, clientX: 600, clientY: 100 });
    fireEvent.pointerMove(b, { clientX: 350, clientY: 280 });
    expect(document.querySelector(".floating")).toBeTruthy();
    fireEvent.pointerUp(b, { clientX: 350, clientY: 280 });
    expect(screen.getAllByRole("button", { name: /^ピース \d/ })).toHaveLength(
      16,
    );
    fireEvent.pointerDown(b, { button: 0, clientX: 600, clientY: 100 });
    fireEvent.pointerMove(b, { clientX: 50, clientY: 64 });
    fireEvent.pointerUp(b, { clientX: 50, clientY: 64 });
    expect(screen.queryByRole("button", { name: "ピース 1" })).toBeNull();
    b = screen.getByRole("button", { name: "ピース 2" });
    fireEvent.pointerDown(b, { button: 0, clientX: 600, clientY: 100 });
    fireEvent.pointerMove(b, { clientX: 150, clientY: 64 });
    fireEvent(window, new Event("resize"));
    fireEvent.pointerUp(b, { clientX: 150, clientY: 64 });
    expect(screen.getAllByRole("button", { name: /^ピース \d/ })).toHaveLength(
      15,
    );
    expect(document.querySelector(".floating")).toBeNull();
  });
  it("hint selects an unplaced piece and automatic hint runs after inactivity", async () => {
    await start();
    fireEvent.click(screen.getByRole("button", { name: /ヒント/ }));
    expect(document.querySelector(".tile.selected")).toBeTruthy();
    expect(document.querySelector(".board .lit")).toBeTruthy();
    vi.useFakeTimers();
    act(() => {
      vi.advanceTimersByTime(13000);
    });
    expect(document.querySelector(".board .lit")).toBeTruthy();
  });
  it("retry regenerates paths and clears all placements", async () => {
    await start();
    const path = document.querySelector(".board path")!.getAttribute("d");
    for (let id = 0; id < 16; id++) place(id);
    fireEvent.click(screen.getByRole("button", { name: /もういっかい/ }));
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.getAllByRole("button", { name: /^ピース \d/ })).toHaveLength(
      16,
    );
    expect(document.querySelector(".board path")!.getAttribute("d")).not.toBe(
      path,
    );
  });
  it("settings restore across mounts", async () => {
    render(<App />);
    fireEvent.click(screen.getByRole("button", { name: "サウンド" }));
    fireEvent.click(screen.getByRole("button", { name: /おたすけ/ }));
    fireEvent.click(screen.getByRole("button", { name: /みほん/ }));
    cleanup();
    render(<App />);
    for (const name of ["サウンド", /おたすけ/, /みほん/])
      expect(
        screen.getByRole("button", { name }).getAttribute("aria-pressed"),
      ).toBe(name === "サウンド" ? "false" : "true");
  });
  it("missing originals block every stage", async () => {
    missing = true;
    render(<App />);
    await waitFor(() =>
      expect(screen.getAllByText("画像が まだないよ")).toHaveLength(4),
    );
    for (const s of stages)
      expect(
        (
          screen.getByRole("button", {
            name: new RegExp(s.name),
          }) as HTMLButtonElement
        ).disabled,
      ).toBe(true);
  });
  it("portrait does not start a game", async () => {
    portrait = true;
    await start();
    expect(screen.queryByTestId("board")).toBeNull();
  });
});

