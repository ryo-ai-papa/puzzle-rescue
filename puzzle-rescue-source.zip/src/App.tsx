import React, { useEffect, useRef, useState } from "react";

import { makePuzzle, isTarget, type Puzzle, type Piece } from "./puzzle";
import { sound, unlockAudio } from "./audio";
import "./style.css";

export const stages = [
  {
    file: "firetruck.jpg",
    name: "しゅつどう！しょうぼうしゃ",
    icon: "🚒",
    color: "#ee675e",
    win: "しゅつどう だいせいこう！",
  },
  {
    file: "excavator.jpg",
    name: "はたらけ！ショベルカー",
    icon: "🚧",
    color: "#efb632",
    win: "おしごと かんりょう！",
  },
  {
    file: "family.jpg",
    name: "おにいちゃんと おとうと",
    icon: "💛",
    color: "#56bbaa",
    win: "おにいちゃんと おとうと、みーつけた！",
  },
  {
    file: "heroes.jpg",
    name: "へんしん！きょうだいヒーロー",
    icon: "⭐",
    color: "#698edb",
    win: "ヒーロー だいせいこう！",
  },
];
const url = (file: string) => `${import.meta.env.BASE_URL}images/${file}`;
type Settings = {
  sound: boolean;
  help: boolean;
  ghost: boolean;
  cleared: number[];
};
const defaults: Settings = {
  sound: true,
  help: false,
  ghost: false,
  cleared: [],
};
function load(): Settings {
  try {
    const saved = localStorage.getItem("puzzle-rescue-v2");
    const s = JSON.parse(saved || localStorage.getItem("puzzle-rescue-v1") || "{}");
    return {
      sound: typeof s.sound === "boolean" ? s.sound : true,
      help: saved && typeof s.help === "boolean" ? s.help : false,
      ghost: saved && typeof s.ghost === "boolean" ? s.ghost : false,
      cleared: Array.isArray(s.cleared)
        ? s.cleared.filter(
            (n: unknown) =>
              Number.isInteger(n) && Number(n) >= 0 && Number(n) < 4,
          )
        : [],
    };
  } catch {
    return defaults;
  }
}
type Asset = { status: "loading" | "ready" | "missing"; w: number; h: number };
type Game = { stage: number; puzzle: Puzzle; placed: number[]; round: number };
type Drag = {
  id: number;
  pointer: number;
  startX: number;
  startY: number;
  x: number;
  y: number;
  moving: boolean;
};
// All stages share one 16:9 canvas. A 4:3 original is contained, never stretched.
// The same background and image transform are used for frame and every piece.
function Picture(props: React.SVGProps<SVGImageElement>) {
  return <><rect width={props.width} height={props.height} fill="#eee6d6"
    clipPath={props.clipPath} mask={props.mask} opacity={props.opacity}/>
    <image {...props} preserveAspectRatio="xMidYMid meet"/></>;
}
function Tile({
  piece,
  puzzle,
  src,
  tag,
}: {
  piece: Piece;
  puzzle: Puzzle;
  src: string;
  tag: string;
}) {
  const clip = `clip-${tag}-${piece.id}`;
  return (
    <svg
      viewBox={`${puzzle.frame + piece.col * puzzle.cellW - puzzle.pad} ${puzzle.frame + piece.row * puzzle.cellH - puzzle.pad} ${puzzle.cellW + 2 * puzzle.pad} ${puzzle.cellH + 2 * puzzle.pad}`}
      aria-hidden="true"
    >
      <defs>
        <clipPath id={clip}>
          <path d={piece.path} />
        </clipPath>
      </defs>
      <Picture
        href={src}
        width={puzzle.width}
        height={puzzle.height}
        clipPath={`url(#${clip})`}
      />
      <path
        d={piece.path}
        fill="none"
        stroke="white"
        strokeWidth="2"
        vectorEffect="non-scaling-stroke"
      />
    </svg>
  );
}
export function App() {
  const [settings, setSettings] = useState(load),
    [assets, setAssets] = useState<Asset[]>(
      stages.map(() => ({ status: "loading", w: 0, h: 0 })),
    ),
    [game, setGame] = useState<Game | null>(null),
    [selected, setSelected] = useState<number | null>(null),
    [hint, setHint] = useState<number | null>(null),
    [drag, setDrag] = useState<Drag | null>(null),
    [near, setNear] = useState(false);
  const board = useRef<SVGSVGElement>(null),
    dragRef = useRef<Drag | null>(null),
    idle = useRef(Date.now()),
    lastNear = useRef(false),
    round = useRef(0),
    won = useRef(-1);
  const complete = !!game && game.placed.length === 16;
  useEffect(() => {
    try {
      localStorage.setItem("puzzle-rescue-v2", JSON.stringify(settings));
    } catch {
      /* Private browsing/storage quota: play still works. */
    }
  }, [settings]);
  useEffect(() => {
    let active = true;
    stages.forEach((s, i) => {
      const img = new Image();
      img.onload = () => {
        if (active)
          setAssets((a) =>
            a.map((x, j) =>
              j === i
                ? { status: "ready", w: img.naturalWidth, h: img.naturalHeight }
                : x,
            ),
          );
      };
      img.onerror = () => {
        if (active)
          setAssets((a) =>
            a.map((x, j) => (j === i ? { status: "missing", w: 0, h: 0 } : x)),
          );
      };
      img.src = url(s.file);
    });
    return () => {
      active = false;
    };
  }, []);
  const cancel = () => {
    dragRef.current = null;
    setDrag(null);
    setNear(false);
    lastNear.current = false;
  };
  useEffect(() => {
    const stop = () => cancel();
    window.addEventListener("resize", stop);
    window.addEventListener("orientationchange", stop);
    window.addEventListener("blur", stop);
    document.addEventListener("visibilitychange", stop);
    return () => {
      window.removeEventListener("resize", stop);
      window.removeEventListener("orientationchange", stop);
      window.removeEventListener("blur", stop);
      document.removeEventListener("visibilitychange", stop);
    };
  }, []);
  useEffect(() => {
    const timer = window.setInterval(() => {
      if (
        game &&
        settings.help &&
        !complete &&
        !dragRef.current &&
        Date.now() - idle.current > 12000
      ) {
        const id =
          selected ?? game.puzzle.order.find((id) => !game.placed.includes(id));
        if (id !== undefined) {
          setSelected(id);
          setHint(id);
        }
        idle.current = Date.now();
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [game, complete, selected, settings.help]);
  useEffect(() => {
    if (!complete || !game || won.current === game.round) return;
    won.current = game.round;
    setSettings((s) => ({
      ...s,
      cleared: [...new Set([...s.cleared, game.stage])],
    }));
    sound("win", settings.sound, game.stage);
  }, [complete, game, settings.sound]);
  const activity = () => {
    idle.current = Date.now();
  };
  const start = (stage: number) => {
    if (
      assets[stage].status !== "ready" ||
      window.matchMedia("(orientation: portrait)").matches
    )
      return;
    unlockAudio();
    cancel();
    setSelected(null);
    setHint(null);
    activity();
    setGame({
      stage,
      puzzle: makePuzzle(1000, 562.5),
      placed: [],
      round: ++round.current,
    });
  };
  const fit = (id: number) => {
    if (!game || game.placed.includes(id)) return;
    const source = document
      .querySelector(`[aria-label="ピース ${id + 1}"]`)
      ?.getBoundingClientRect();
    const destination = board.current?.getBoundingClientRect();
    const currentRound = game.round;
    if (
      !dragRef.current?.moving &&
      source &&
      destination &&
      destination.width > 0 &&
      !window.matchMedia("(prefers-reduced-motion: reduce)").matches
    ) {
      const piece = game.puzzle.pieces[id],
        puzzle = game.puzzle;
      const dx =
        ((source.left + source.width / 2 - destination.left) /
          destination.width) *
          puzzle.width -
        (puzzle.frame + (piece.col + 0.5) * puzzle.cellW);
      const dy =
        ((source.top + source.height / 2 - destination.top) /
          destination.height) *
          puzzle.height -
        (puzzle.frame + (piece.row + 0.5) * puzzle.cellH);
      requestAnimationFrame(() => {
        if (round.current === currentRound)
          board.current?.querySelector(`[data-piece="${id}"]`)?.animate?.(
            [
              { transform: `translate(${dx}px,${dy}px)`, opacity: 0.7 },
              { transform: "translate(0,0)", opacity: 1 },
            ],
            { duration: 280, easing: "ease-out" },
          );
      });
    }
    sound(game.placed.length === 14 ? "last" : "fit", settings.sound);
    setGame((g) =>
      g && !g.placed.includes(id) ? { ...g, placed: [...g.placed, id] } : g,
    );
    setSelected(null);
    setHint(null);
    cancel();
    activity();
  };
  const target = (x: number, y: number, id: number) => {
    if (!game || !board.current) return false;
    const r = board.current.getBoundingClientRect();
    return isTarget(
      game.puzzle,
      id,
      ((x - r.left) / r.width) * game.puzzle.width,
      ((y - r.top) / r.height) * game.puzzle.height,
      settings.help,
    );
  };
  const down = (e: React.PointerEvent<HTMLButtonElement>, id: number) => {
    if (dragRef.current || e.button !== 0) return;
    unlockAudio();
    activity();
    setSelected(id);
    setHint(null);
    sound("pick", settings.sound);
    const d = {
      id,
      pointer: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      x: e.clientX,
      y: e.clientY,
      moving: false,
    };
    dragRef.current = d;
    setDrag(d);
    e.currentTarget.setPointerCapture(e.pointerId);
  };
  const move = (e: React.PointerEvent) => {
    const d = dragRef.current;
    if (!d || d.pointer !== e.pointerId) return;
    const moving =
      d.moving || Math.hypot(e.clientX - d.startX, e.clientY - d.startY) > 9;
    const next = { ...d, x: e.clientX, y: e.clientY, moving };
    dragRef.current = next;
    setDrag(next);
    const n = moving && target(e.clientX, e.clientY - 24, d.id);
    setNear(n);
    if (n && !lastNear.current) sound("near", settings.sound);
    lastNear.current = n;
    activity();
  };
  const up = (e: React.PointerEvent) => {
    const d = dragRef.current;
    if (!d || d.pointer !== e.pointerId) return;
    if (d.moving && target(e.clientX, e.clientY - 24, d.id)) fit(d.id);
    cancel();
  };
  const giveHint = () => {
    if (!game) return;
    unlockAudio();
    activity();
    const id =
      selected ?? game.puzzle.order.find((id) => !game.placed.includes(id));
    if (id !== undefined) {
      setSelected(id);
      setHint(id);
    }
  };
  const toggle = (key: "sound" | "help" | "ghost") => {
    unlockAudio();
    if(key === "help") {setHint(null);activity();}
    setSettings((s) => ({ ...s, [key]: !s[key] }));
  };
  const goHome = () => {
    cancel();
    setGame(null);
    setSelected(null);
    setHint(null);
  };
  const p = game?.puzzle,
    s = game ? stages[game.stage] : null;
  const bounds = board.current?.getBoundingClientRect();
  const floatingW =
    p && bounds ? ((p.cellW + 2 * p.pad) / p.width) * bounds.width * 1.1 : 100;
  const floatingH =
    p && bounds
      ? ((p.cellH + 2 * p.pad) / p.height) * bounds.height * 1.1
      : 100;
  return (
    <>
      <div className="rotate">
        <span className="rotating-phone">▯</span>
        <h1>スマホを よこにしてね！</h1>
        <p>よこにすると あそべるよ</p>
        <span>☁️　⭐　☁️</span>
      </div>
      <main onPointerDownCapture={activity}>
        {!game ? (
          <section className="home">
            <header className="home-header">
              <div>
                <div className="brand">🚒 しゅつどう！パズルレスキュー！</div>
                <h1>
                  どのパズルで <em>あそぶ？</em>
                </h1>
              </div>
              <button
                className="round"
                aria-label="サウンド"
                aria-pressed={settings.sound}
                onClick={() => toggle("sound")}
              >
                {settings.sound ? "🔊" : "🔇"}
              </button>
            </header>
            <div className="stage-list">
              {stages.map((s, i) => (
                <button
                  key={s.file}
                  className="stage"
                  style={{ "--accent": s.color } as React.CSSProperties}
                  onClick={() => start(i)}
                  disabled={assets[i].status !== "ready"}
                >
                  <div className="stage-photo">
                    {assets[i].status === "ready" ? (
                      <img src={url(s.file)} alt={s.name} />
                    ) : (
                      <div className="missing">
                        <span>
                          {assets[i].status === "loading"
                            ? "…"
                            : "画像が まだないよ"}
                        </span>
                        <small>{s.file}</small>
                      </div>
                    )}
                    <span className="stage-number">{i + 1}</span>
                    {settings.cleared.includes(i) && (
                      <span className="badge" aria-label="クリア済み">
                        ★
                      </span>
                    )}
                  </div>
                  <div className="stage-label">
                    <span>{s.name}</span>
                    <b>▶</b>
                  </div>
                </button>
              ))}
            </div>
            <footer>
              <span>⭐ 16ピース ・ ゆっくり あそぼう</span>
              <div className="settings">
                <button
                  aria-pressed={settings.help}
                  onClick={() => toggle("help")}
                >
                  💡 おたすけ {settings.help ? "ON" : "OFF"}
                </button>
                <button
                  aria-pressed={settings.ghost}
                  onClick={() => toggle("ghost")}
                >
                  🖼️ みほん {settings.ghost ? "ON" : "OFF"}
                </button>
              </div>
            </footer>
            {assets.some((a) => a.status === "missing") && (
              <p className="asset-note">
                保護者の方へ：public/images/
                に指定の元画像を配置してください。代替画像は使用していません。
              </p>
            )}
          </section>
        ) : (
          <section className={`game ${complete ? "complete" : ""}`}>
            <header className="toolbar">
              <button aria-label="ステージ選択に戻る" onClick={goHome}>
                ◀ <span>もどる</span>
              </button>
              <h1>{s!.name}</h1>
              <strong className="progress" aria-live="polite">
                ⭐ {game.placed.length}
                <small>/16</small>
              </strong>
              <button
                className="hint-button"
                title="押したときだけ、選んだピースの場所を教える"
                onClick={giveHint}
                disabled={complete}
              >
                💡 <span>ヒント</span>
              </button>
              <button
                aria-label="サウンド"
                aria-pressed={settings.sound}
                onClick={() => toggle("sound")}
              >
                {settings.sound ? "🔊" : "🔇"}
              </button>
            </header>
            <div
              className="play-area"
              style={
                {
                  "--board-share": p!.width / p!.height < 1 ? "48%" : "65%",
                } as React.CSSProperties
              }
            >
              <div className="board-area">
                <div className="board-fit">
                  <svg
                    ref={board}
                    className="board"
                    data-testid="board"
                    style={
                      {
                        aspectRatio: `${p!.width}/${p!.height}`,
                        "--ratio": p!.width / p!.height,
                      } as React.CSSProperties
                    }
                    viewBox={`0 0 ${p!.width} ${p!.height}`}
                    onClick={(e) => {
                      if (
                        selected !== null &&
                        target(e.clientX, e.clientY, selected)
                      )
                        fit(selected);
                    }}
                  >
                    <defs>
                      <mask id="picture-frame" maskUnits="userSpaceOnUse" x="0" y="0" width={p!.width} height={p!.height}>
                        <rect width={p!.width} height={p!.height} fill="white"/>
                        <rect x={p!.frame} y={p!.frame} width={p!.width-2*p!.frame} height={p!.height-2*p!.frame} fill="black"/>
                      </mask>
                      <linearGradient id="cardboard" x1="0" y1="0" x2=".4" y2="1">
                        <stop stopColor="#c3bcae"/><stop offset="1" stopColor="#e1dacc"/>
                      </linearGradient>
                      <filter id="recess" x="-15%" y="-15%" width="130%" height="130%" colorInterpolationFilters="sRGB">
                        <feGaussianBlur in="SourceAlpha" stdDeviation="3" result="blur"/>
                        <feOffset in="blur" dx="2" dy="4" result="shift"/>
                        <feComposite in="SourceAlpha" in2="shift" operator="out" result="edge"/>
                        <feFlood floodColor="#4b3c29" floodOpacity=".48"/>
                        <feComposite in2="edge" operator="in"/>
                        <feComposite in2="SourceGraphic" operator="over"/>
                      </filter>
                    </defs>
                    <rect width={p!.width} height={p!.height} fill="#d6cebf"/>
                    <Picture data-testid="frame-image" href={url(s!.file)} width={p!.width} height={p!.height} mask="url(#picture-frame)"/>
                    {p!.pieces.map((piece) => {
                      const done = game.placed.includes(piece.id),
                        lit =
                          !done &&
                          (hint === piece.id ||
                            (settings.help && selected === piece.id) ||
                            (settings.help && near && selected === piece.id));
                      const clip = `board-${game.round}-${piece.id}`;
                      return (
                        <g
                          key={piece.id}
                          data-piece={piece.id}
                          className={`${done ? "placed" : ""} ${lit ? "lit" : ""}`}
                        >
                          <defs>
                            <clipPath id={clip}>
                              <path d={piece.path} />
                            </clipPath>
                          </defs>
                          {!done && <path className="socket" d={piece.path} fill="url(#cardboard)" filter="url(#recess)"/>}
                          {!done && settings.ghost && <Picture data-testid="ghost-image" href={url(s!.file)} width={p!.width} height={p!.height} clipPath={`url(#${clip})`} opacity=".22"/>}
                          {done && (
                            <Picture
                              href={url(s!.file)}
                              width={p!.width}
                              height={p!.height}
                              clipPath={`url(#${clip})`}
                            />
                          )}
                          <path
                            d={piece.path}
                            fill={lit ? "#ffdf6999" : "transparent"}
                            stroke={
                              complete
                                ? "none"
                                : done
                                  ? "#ffffffaa"
                                  : lit
                                    ? "#f3a900"
                                    : "#9c9383"
                            }
                            strokeWidth={lit ? 3 : 1.2}
                            vectorEffect="non-scaling-stroke"
                          />
                          {!done && <title>{piece.id + 1}ばんの ばしょ</title>}
                        </g>
                      );
                    })}
                  </svg>
                </div>
                <div className="board-bottom">
                  <span>
                    {selected === null
                      ? "ピースを えらんでね"
                      : "ここかな？ タップで おけるよ"}
                  </span>
                  <button
                    onClick={() => toggle("ghost")}
                    title="完成図を薄く表示する・消す"
                    aria-pressed={settings.ghost}
                  >
                    🖼️ みほん {settings.ghost ? "ON" : "OFF"}
                  </button>
                  <button
                    onClick={() => toggle("help")}
                    title="吸着の範囲を広げ、正解位置と無操作時のヒントを表示する"
                    aria-pressed={settings.help}
                  >
                    💡 おたすけ {settings.help ? "ON" : "OFF"}
                  </button>
                </div>
              </div>
              <aside className="tray-area">
                <div className="tray-heading">
                  <b>🧩 ピース</b>
                  <span>あと {16 - game.placed.length} こ</span>
                </div>
                <div className="tray" aria-label="ピース置き場">
                  <div className="tray-grid">
                    {p!.order
                      .filter((id) => !game.placed.includes(id))
                      .map((id) => (
                        <button
                          key={id}
                          aria-label={`ピース ${id + 1}`}
                          aria-pressed={selected === id}
                          className={`tile ${selected === id ? "selected" : ""} ${drag?.moving && drag.id === id ? "dragging" : ""}`}
                          onPointerDown={(e) => down(e, id)}
                          onPointerMove={move}
                          onPointerUp={up}
                          onPointerCancel={cancel}
                          onLostPointerCapture={cancel}
                          onClick={(e) => {
                            if (e.detail === 0) {
                              unlockAudio();
                              setSelected(id);
                            }
                          }}
                        >
                          <Tile
                            piece={p!.pieces[id]}
                            puzzle={p!}
                            src={url(s!.file)}
                            tag={`tray-${game.round}`}
                          />
                        </button>
                      ))}
                  </div>
                  <p className="scroll-note">↕ あいているところで スクロール</p>
                </div>
              </aside>
            </div>
            {complete && (
              <div
                className={`celebration theme-${game.stage}`}
                role="dialog"
                aria-modal="true"
                aria-label="クリア"
              >
                <div className="win-image">
                  <div
                    className="win-art"
                    style={
                      {
                        "--ratio": p!.width / p!.height,
                        aspectRatio: `${p!.width}/${p!.height}`,
                      } as React.CSSProperties
                    }
                  >
                    <img src={url(s!.file)} alt={s!.name} />
                    <div className="burst" />
                    <div className="sparkles">
                      {Array.from({ length: 12 }, (_, i) => (
                        <span
                          key={i}
                          style={{
                            left: `${4 + ((i * 29) % 94)}%`,
                            top: `${(i * 37) % 90}%`,
                            animationDelay: `${i * 0.13}s`,
                          }}
                        >
                          ★
                        </span>
                      ))}
                    </div>
                    {game.stage === 0 && <div className="mini-truck">🚒</div>}
                    {game.stage === 1 && (
                      <svg className="excavator" viewBox="0 0 180 100">
                        <path
                          d="M20 75h80"
                          stroke="#284655"
                          strokeWidth="18"
                          strokeLinecap="round"
                        />
                        <path d="M30 35h42v35H25V50z" fill="#ffd15a" />
                        <path d="M39 40h22v22H39z" fill="#bcecff" />
                        <g className="bucket">
                          <path
                            d="M75 55L110 15l35 40"
                            stroke="#f7bf32"
                            strokeWidth="13"
                            fill="none"
                          />
                          <path d="M130 50h32v25q-28 10-32-25" fill="#efac22" />
                        </g>
                      </svg>
                    )}
                  </div>
                </div>
                <div className="win-panel">
                  <span className="win-star">★</span>
                  <h2>やったー！</h2>
                  <p>{s!.win}</p>
                  <button className="primary" onClick={() => start(game.stage)}>
                    ↻ もういっかい！
                  </button>
                  <button onClick={goHome}>ほかのパズル！ ▶</button>
                </div>
              </div>
            )}
          </section>
        )}
        {drag?.moving && game && (
          <div
            className="floating"
            style={{
              width: floatingW,
              height: floatingH,
              left: Math.max(
                floatingW / 2,
                Math.min(window.innerWidth - floatingW / 2, drag.x),
              ),
              top: Math.max(
                floatingH / 2,
                Math.min(window.innerHeight - floatingH / 2, drag.y - 24),
              ),
            }}
          >
            <Tile
              piece={game.puzzle.pieces[drag.id]}
              puzzle={game.puzzle}
              src={url(stages[game.stage].file)}
              tag="floating"
            />
          </div>
        )}
      </main>
    </>
  );
}
