export type Point = { x: number; y: number };
export type Cubic = { from: Point; a: Point; b: Point; to: Point };
export type Edge = Cubic[];
export type Piece = {
  id: number;
  row: number;
  col: number;
  path: string;
  edges: Edge[];
};
export type Puzzle = {
  width: number;
  height: number;
  cellW: number;
  cellH: number;
  frame: number;
  pad: number;
  pieces: Piece[];
  order: number[];
};
export function reverse(edge: Edge): Edge {
  return [...edge]
    .reverse()
    .map((c) => ({ from: c.to, a: c.b, b: c.a, to: c.from }));
}
// Every shared edge is generated once. Reverse swaps control points exactly.
function edge(from: Point, to: Point, depth: number, rng: () => number): Edge {
  const dx = to.x - from.x,
    dy = to.y - from.y,
    length = Math.hypot(dx, dy);
  const sign = rng() < 0.5 ? -1 : 1;
  const center = 0.43 + rng() * 0.14;
  const h = depth * (0.27 + rng() * 0.06) * sign;
  const p = (u: number, v: number): Point => ({
    x: from.x + dx * u - (dy / length) * v,
    y: from.y + dy * u + (dx / length) * v,
  });
  // Broad asymmetric lobes and shallow shoulders. No straight internal runs.
  // Monotonic longitudinal coordinates prevent loops / narrow button necks.
  const knots = [[0,0],[.17,-h*.18],[center-.12,h*.78],
    [center+.10,h],[.85,-h*.12],[1,0]];
  const slope = (i:number) => {
    const a=knots[Math.max(0,i-1)], b=knots[Math.min(knots.length-1,i+1)];
    return (b[1]-a[1])/(b[0]-a[0]);
  };
  return knots.slice(0,-1).map(([u,v],i)=>{
    const [endU,endV]=knots[i+1], du=(endU-u)/3;
    return {from:i===0?from:p(u,v),a:p(u+du,v+slope(i)*du),
      b:p(endU-du,endV-slope(i+1)*du),to:i===knots.length-2?to:p(endU,endV)};
  });
}
const line = (from: Point, to: Point): Edge => [{ from, a: from, b: to, to }];
const xy = (p: Point) => `${p.x},${p.y}`;
export function makePuzzle(
  width: number,
  height: number,
  rng = Math.random,
): Puzzle {
  const frame = Math.min(width,height)*.055;
  const cw = (width-2*frame) / 4,
    ch = (height-2*frame) / 4,
    depth = Math.min(cw, ch);
  const points = Array.from({length:5},(_,r)=>Array.from({length:5},(_,c)=>({
    x:frame+c*cw+(c>0&&c<4&&r>0&&r<4?(rng()-.5)*depth*.17:0),
    y:frame+r*ch+(c>0&&c<4&&r>0&&r<4?(rng()-.5)*depth*.17:0),
  })));
  const horizontal: Edge[][] = Array.from({ length: 5 }, (_, r) =>
    Array.from({ length: 4 }, (_, c) =>
      r === 0 || r === 4
        ? line(points[r][c], points[r][c+1])
        : edge(
            points[r][c], points[r][c+1],
            depth,
            rng,
          ),
    ),
  );
  const vertical: Edge[][] = Array.from({ length: 4 }, (_, r) =>
    Array.from({ length: 5 }, (_, c) =>
      c === 0 || c === 4
        ? line(points[r][c], points[r+1][c])
        : edge(
            points[r][c], points[r+1][c],
            depth,
            rng,
          ),
    ),
  );
  const pieces = Array.from({ length: 16 }, (_, id) => {
    const row = Math.floor(id / 4),
      col = id % 4;
    const edges = [
      horizontal[row][col],
      vertical[row][col + 1],
      reverse(horizontal[row + 1][col]),
      reverse(vertical[row][col]),
    ];
    return {
      id,
      row,
      col,
      edges,
      path:
        `M${xy(edges[0][0].from)} ` +
        edges
          .flat()
          .map((s) => `C${xy(s.a)} ${xy(s.b)} ${xy(s.to)}`)
          .join(" ") +
        " Z",
    };
  });
  const order = pieces.map((p) => p.id);
  for (let i = 15; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [order[i], order[j]] = [order[j], order[i]];
  }
  return {
    width,
    height,
    cellW: cw,
    cellH: ch,
    frame,
    pad: depth * 0.48,
    pieces,
    order,
  };
}
export function isTarget(
  puzzle: Puzzle,
  id: number,
  x: number,
  y: number,
  help: boolean,
) {
  const p = puzzle.pieces[id];
  // Less than half a cell: adjacent cell centers can never accept this piece.
  const radius = help ? 0.49 : 0.36;
  return (
    Math.abs(x - puzzle.frame - (p.col + 0.5) * puzzle.cellW) <= puzzle.cellW * radius &&
    Math.abs(y - puzzle.frame - (p.row + 0.5) * puzzle.cellH) <= puzzle.cellH * radius
  );
}
