let ctx: AudioContext | undefined;
let last = 0;
export function unlockAudio() {
  try {
    ctx ??= new (
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext
    )();
    if (ctx.state === "suspended") void ctx.resume().catch(() => {});
  } catch {
    /* Sound is optional. */
  }
}
export function sound(
  kind: "pick" | "near" | "fit" | "last" | "win",
  enabled: boolean,
  stage = 0,
) {
  if (!enabled || !ctx || ctx.state !== "running") return;
  if (kind !== "win" && performance.now() - last < 90) return;
  last = performance.now();
  const notes =
    kind === "win"
      ? [
          [523, 659, 784, 1047],
          [330, 440, 554, 880],
          [523, 784, 659, 1047],
          [392, 523, 784, 1047],
        ][stage]
      : kind === "last"
        ? [659, 784, 988]
        : kind === "fit"
          ? [880, 1320]
          : kind === "near"
            ? [740]
            : [420];
  notes.forEach((f, i) => {
    const o = ctx!.createOscillator(),
      g = ctx!.createGain(),
      t = ctx!.currentTime + i * 0.15;
    o.type = "sine";
    o.frequency.setValueAtTime(f, t);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.045, t + 0.015);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.23);
    o.connect(g);
    g.connect(ctx!.destination);
    o.start(t);
    o.stop(t + 0.25);
  });
  if (kind === "win" && stage === 0) {
    const o = ctx.createOscillator(),
      g = ctx.createGain(),
      t = ctx.currentTime + 0.65;
    o.frequency.setValueAtTime(550, t);
    o.frequency.linearRampToValueAtTime(760, t + 0.4);
    o.frequency.linearRampToValueAtTime(550, t + 0.8);
    g.gain.setValueAtTime(0.025, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 1);
    o.connect(g);
    g.connect(ctx.destination);
    o.start(t);
    o.stop(t + 1);
  }
  if (kind === "win" && (stage === 1 || stage === 2)) {
    for (let i = 0; i < 4; i++) {
      const b = ctx.createBuffer(1, ctx.sampleRate * 0.08, ctx.sampleRate),
        data = b.getChannelData(0);
      for (let j = 0; j < data.length; j++)
        data[j] = (Math.random() * 2 - 1) * (1 - j / data.length);
      const n = ctx.createBufferSource(),
        g = ctx.createGain();
      g.gain.value = stage === 2 ? 0.055 : 0.025;
      n.buffer = b;
      n.connect(g);
      g.connect(ctx.destination);
      n.start(ctx.currentTime + 0.7 + i * 0.17);
    }
  }
}
