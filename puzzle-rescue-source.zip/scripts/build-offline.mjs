import { build } from 'esbuild';
import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import vm from 'node:vm';

const root=fileURLToPath(new URL('../',import.meta.url));
const images={};
for(const name of ['firetruck.jpg','excavator.jpg','family.jpg','heroes.jpg']) {
  images[name]='data:image/jpeg;base64,'+(await readFile(path.join(root,'public/images',name))).toString('base64');
}
const result=await build({
  absWorkingDir:root,entryPoints:['src/main.tsx'],bundle:true,write:false,
  outfile:'offline.js',format:'iife',platform:'browser',target:['safari16','chrome100'],
  minify:true,jsx:'automatic',define:{'process.env.NODE_ENV':'"production"'},
  plugins:[{name:'embed-original-images',setup(builder){
    builder.onLoad({filter:/[\\/]App\.tsx$/},async({path:sourcePath})=>{
      let source=await readFile(sourcePath,'utf8');
      const original='const url = (file: string) => `${import.meta.env.BASE_URL}images/${file}`;';
      if(!source.includes(original))throw new Error('Image URL function changed; update offline builder.');
      source=source.replace(original,`const embeddedImages: Record<string,string> = ${JSON.stringify(images)};\nconst url = (file: string) => embeddedImages[file];`);
      return {contents:source,loader:'tsx',resolveDir:path.dirname(sourcePath)};
    });
  }}],
});
const js=result.outputFiles.find(f=>f.path.endsWith('.js')).text;
const css=result.outputFiles.find(f=>f.path.endsWith('.css')).text;
new vm.Script(js); // Syntax validation without running browser code.
if(/import\.meta|https?:\/\//.test(css))throw new Error('External CSS dependency detected');
const html=`<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#caedff"><title>しゅつどう！パズルレスキュー！</title><style>${css}</style></head><body><div id="root"></div><script>${js.replace(/<\/script/gi,'<\\/script')}</script></body></html>`;
const output=path.resolve(root,'../パズルレスキュー.html');
await writeFile(output,html,'utf8');
console.log(`Created: ${output}\nImages: ${Object.keys(images).length}, size: ${Buffer.byteLength(html)} bytes. No server or module loading required.`);
