import {existsSync} from 'node:fs';
const files=['firetruck.jpg','excavator.jpg','family.jpg','heroes.jpg'];
const missing=files.filter(f=>!existsSync(new URL('../public/images/'+f,import.meta.url)));
if(missing.length){console.error('公開できません。元画像が不足しています:\n'+missing.map(f=>'public/images/'+f).join('\n'));process.exitCode=1;}else console.log('4枚の画像ファイルがあります。内容・トリミング・公開許可は保護者が確認してください。');
